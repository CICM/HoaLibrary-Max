function msg_int(v)
{
this.patcher.locked = v;
}